#!/usr/bin/env python3
import argparse, json, re, shutil, subprocess, os, uuid
from pathlib import Path

def read_txt(p: Path) -> str:
    try:
        return p.read_text(errors="ignore")
    except Exception:
        return ""

def patch_config_from_rtl_f(config_json: Path, rtl_f: Path, sdc_file: Path):
    cfg = json.loads(config_json.read_text())
    files = []
    if rtl_f.exists():
        for line in read_txt(rtl_f).splitlines():
            s = line.strip()
            if not s or s.startswith("#"):
                continue
            files.append(f"dir::{s}")
    if files:
        cfg["VERILOG_FILES"] = files
    cfg["BASE_SDC_FILE"] = f"dir::{sdc_file.name}"
    config_json.write_text(json.dumps(cfg, indent=2))

def parse_period_from_sdc(sdc: Path):
    txt = read_txt(sdc)
    m = re.search(r"-period\s+([\d.]+)", txt)
    return float(m.group(1)) if m else None

def parse_area(stat_file: Path):
    txt = read_txt(stat_file)
    for line in txt.splitlines():
        if "Chip area for module" in line:
            nums = re.findall(r"([\d.]+)", line)
            if nums:
                return float(nums[-1])
    return None

def parse_wns(sta_file: Path):
    """
    Parse *setup* WNS from an OpenROAD STA log.

    Looks for the 'report_worst_slack -max (Setup)' section and then
    extracts the numeric value from the following 'worst slack' line.
    Falls back to the first 'worst slack' in the file if the section
    is not found.
    """
    txt = read_txt(sta_file)
    lines = txt.splitlines()

    in_setup_section = False

    # First, try to get the setup (max) worst slack explicitly
    for line in lines:
        low = line.lower()

        # Start of setup WNS section
        if "report_worst_slack -max" in low and "setup" in low:
            in_setup_section = True
            continue

        # If we hit the hold section, stop searching for setup
        if "report_worst_slack -min" in low and "hold" in low:
            if in_setup_section:
                break
            in_setup_section = False

        # Inside setup section, grab the 'worst slack' line
        if in_setup_section and "worst slack" in low:
            parts = line.split()
            # Typically: ["worst", "slack", "3.19"]
            for tok in reversed(parts):
                try:
                    return float(tok)
                except ValueError:
                    continue
            # If parsing fails, still stop looking in this section
            break

    # Fallback: if for some reason the explicit section isn't found,
    # take the first numeric value from any 'worst slack' line
    for line in lines:
        if "worst slack" in line.lower():
            parts = line.split()
            for tok in reversed(parts):
                try:
                    return float(tok)
                except ValueError:
                    continue

    return None


def parse_power(sta_file: Path):
    """
    Extract total power from STA report.
    Returns power in mW (milliwatts).
    """
    txt = read_txt(sta_file)
    
    # Look for the power_report section
    # Format: "Total    1.05e-01   9.64e-02   1.11e-07   2.02e-01 100.0%"
    #         where the 4th column is total power in Watts
    
    in_power_section = False
    for line in txt.splitlines():
        # Detect start of power section
        if 'power_report' in line.lower() or 'report_power' in line.lower():
            in_power_section = True
            continue
        
        # Detect end of power section
        if 'power_report_end' in line.lower():
            break
        
        # Look for the "Total" line in power section
        if in_power_section and line.strip().startswith('Total'):
            # Split by whitespace and extract columns
            parts = line.split()
            # Format: ['Total', '1.05e-01', '9.64e-02', '1.11e-07', '2.02e-01', '100.0%']
            if len(parts) >= 5:
                try:
                    # 5th element (index 4) is total power in Watts
                    power_watts = float(parts[4])
                    # Convert to milliwatts
                    return power_watts * 1000.0
                except (ValueError, IndexError):
                    continue
    
    return None

def run_flow(flow_tcl: Path, design_dir: Path, config_json: Path):
    cmd = ["tclsh", str(flow_tcl), "-design", str(design_dir), "-config", str(config_json)]
    # Set PWD environment variable explicitly to avoid OpenLane errors in parallel requests
    env = os.environ.copy()
    env['PWD'] = str(design_dir)
    run = subprocess.run(cmd, cwd=design_dir, capture_output=True, text=True, env=env)
    if run.returncode != 0:
        raise RuntimeError(f"flow.tcl failed:\nSTDOUT:\n{run.stdout}\n\nSTDERR:\n{run.stderr}")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--design", required=True, help="path to extracted design dir")
    ap.add_argument("--out", required=True, help="output dir (API will zip this)")
    args = ap.parse_args()

    design_dir = Path(args.design).resolve()
    out_dir    = Path(args.out).resolve()
    out_dir.mkdir(parents=True, exist_ok=True)

    # evaluator dir is the folder containing run.py
    eval_dir = Path(__file__).resolve().parent

    # --- OpenLane root + designs dir ---
    openlane_root = Path("/openlane")
    designs_root  = openlane_root / "designs"
    # Use unique name with UUID to avoid conflicts in parallel requests
    design_name   = f"{design_dir.name}_{uuid.uuid4().hex[:8]}"
    design_target = designs_root / design_name

    if design_target.exists():
        shutil.rmtree(design_target)
    shutil.copytree(design_dir, design_target)

    # Copy evaluator resources
    flow_tcl = eval_dir / "flow.tcl"
    config_json_template = eval_dir / "config.json"
    constraints_sdc = eval_dir / "constraints.sdc"

    shutil.copy(flow_tcl, openlane_root / "flow.tcl")
    shutil.copy(config_json_template, design_target / "config.json")
    shutil.copy(constraints_sdc, design_target / "constraints.sdc")

    # Patch config.json with RTL
    patch_config_from_rtl_f(design_target / "config.json",
                            design_target / "rtl.f",
                            design_target / "constraints.sdc")

    # Run flow
    run_flow(openlane_root / "flow.tcl", design_target, design_target / "config.json")

    # Locate latest run
    runs_root = design_target / "runs"
    latest = None
    if runs_root.exists():
        candidates = [p for p in runs_root.glob("*") if p.is_dir()]
        latest = max(candidates, key=lambda p: p.stat().st_mtime) if candidates else None
    if latest is None:
        raise RuntimeError("No OpenLane runs found under design/runs")

    syn_stat = latest / "reports" / "synthesis" / "1-synthesis.DELAY_3.stat.rpt"
    syn_sta = latest / "logs" / "synthesis" / "2-sta.log"
    
    area_um2 = parse_area(syn_stat)
    period_ns = parse_period_from_sdc(design_target / "constraints.sdc")
    wns_ns = parse_wns(syn_sta)
    power_mw = parse_power(syn_sta)  # NEW: Extract power

    fmax_mhz = None
    if period_ns is not None and wns_ns is not None:
        ach = period_ns - wns_ns
        if ach > 0:
            fmax_mhz = 1000.0 / ach

    # Save reports into output dir
    rep_src = latest / "reports"
    rep_dst = out_dir / "reports"
    if rep_src.exists():
        if rep_dst.exists():
            shutil.rmtree(rep_dst)
        shutil.copytree(rep_src, rep_dst)

    result = {
        "area_um2": area_um2,
        "sdc_period_ns": period_ns,
        "wns_ns": wns_ns,
        "fmax_mhz": fmax_mhz,
        "power_mw": power_mw,  # NEW: Add power to results
        "run_dir": str(latest)
    }

    (out_dir / "results.json").write_text(json.dumps(result, indent=2))
    print(json.dumps(result))  # stdout JSON

if __name__ == "__main__":
    main()