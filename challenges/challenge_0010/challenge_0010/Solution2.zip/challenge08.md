Challenge_0008: RV32IMCK Processor The purpose of this challenge is to design a RISC-V based RV32IMCK processor core and describe that using SystemVerilog/Verilog HDL languages. This is a straight extension of the rv32imc processor that we designed in challenge_0007. Everything stays the same: same ports as before, same tracer usage, same local and evaluation flows, same submission format, same disqualifiers. The top module name should be rv32imc_top. The external interface from the rv32imc_top should stay the same as was in the previous challenges (Challenge_0007, Challenge_0006, Challenge_0005). 
Your job is to add full support for the following extensions on top of RV32IMC: 
    ● Zkne / Zknd (AES instructions): aes32esi, aes32esmi, aes32dsi, aes32dsmi 
    ● Zknh (SHA-256 instructions): sha256sum0, sha256sum1, sha256sig0, sha256sig1 
    ● Zbkb / Zbkc / Zbkx / Zbb (Bit-Manipulation for Crypto): andn, orn, xnor, rol, ror, pack, packh, clmul, clmulh, xperm4, xperm8 
Please make sure to carefully follow these steps as well: 
    ● Reset/Tracer: Unchanged from previous challenge. Connect your tracer exactly like you did in the previous challange.  
    ● Submission: Submission should be done exactly like before, with rtl.f at the root of the zip folder. 
    ● Synthesis/Flow: Your design should be synthesizeable. 
    ● Functionality Gate: Your design should be at least 80% functionally correct, any design below that requirement will get straight zero score. 
    ● Scoring Weights: Functionality 50%, Performance 25%, Area 25%, Power 0%. 
    ● Disqualify if: Wrong top name/ports, missing (or nonworking) tracer, unsynthesizable RTL, or functionality < 100%.
Note: If you are a new miner, and this your first challenge, please look at the documentation of the previous challenge to understand the requirements properly. 