#!/usr/bin/env python3
import argparse, json, subprocess, sys, shutil, zipfile
from pathlib import Path
import pandas as pd
from datetime import datetime

def run_cmd(cmd, cwd: Path):
    p = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True)
    return p.returncode, (p.stdout or "") + (p.stderr or "")

def copy_resources(src: Path, dst: Path):
    # merge bundle into design root (Makefile, Regression.mk, tb_files.f, tests/, scripts/, top_module.txt, etc.)
    for item in src.iterdir():
        target = dst / item.name
        if target.exists():
            if target.is_dir():
                shutil.rmtree(target)
            else:
                target.unlink()
        if item.is_dir():
            shutil.copytree(item, target)
        else:
            shutil.copy(item, target)

def read_top_module(design_dir: Path) -> str:
    t = design_dir / "top_module.txt"
    if not t.exists():
        raise FileNotFoundError("top_module.txt not found after copying resources")
    return t.read_text().strip()

def make_verilator_f(design_dir: Path) -> Path:
    rtl_f = design_dir / "rtl.f"
    tb_f  = design_dir / "tb_files.f"
    out_f = design_dir / "verilator.f"

    if not rtl_f.exists():
        raise FileNotFoundError(f"rtl.f not found in {design_dir}")

    if not tb_f.exists():
        raise FileNotFoundError(f"tb_files.f not found in {design_dir}")

    lines = []
    lines.extend(rtl_f.read_text().splitlines())
    lines.extend(tb_f.read_text().splitlines())

    with out_f.open("w") as f:
        for line in lines:
            s = line.strip()
            if not s or s.startswith("#"):
                continue
            f.write(s + "\n")

    return out_f

def find_latest_summary(results_dir: Path) -> Path | None:
    cands = list(results_dir.rglob("regression_summary.csv"))
    return max(cands, key=lambda p: p.stat().st_mtime) if cands else None

def compute_score(summary_csv: Path):
    df = pd.read_csv(summary_csv)
    total, passed = 0, 0
    for _, row in df.iterrows():
        try:
            ip = int(row.get("Instr_Passed", 0))
            iff = int(row.get("Instr_Failed", 0))
        except Exception:
            continue
        total += ip + iff
        passed += ip
    return (passed / total) if total > 0 else 0.0, total, passed

def compute_ipc(summary_csv: Path):
    df = pd.read_csv(summary_csv)
    passed_df = df[df["Status"] == "PASSED"]
    if passed_df.empty:
        return 0.0, 0, 0
    instr_total = int(passed_df["Instr_Passed"].sum())
    cycles_total = int(passed_df["Cycles"].sum()) if "Cycles" in passed_df.columns else 0
    ipc = (instr_total / cycles_total) if cycles_total > 0 else 0.0
    return float(ipc), instr_total, cycles_total

def zip_dir(src: Path, out_zip: Path) -> str:
    with zipfile.ZipFile(out_zip, "w", zipfile.ZIP_DEFLATED) as z:
        for p in src.rglob("*"):
            z.write(p, p.relative_to(src))
    return str(out_zip)

def main():
    ap = argparse.ArgumentParser(description="Verilator evaluator runner")
    ap.add_argument("--design", required=True, help="path to miner design (unzipped; rtl.f at this root)")
    ap.add_argument("--resources", required=True, help="path to evaluator bundle (unzipped)")
    args = ap.parse_args()

    design_dir = Path(args.design).resolve()
    resources  = Path(args.resources).resolve()

    # 0) merge evaluator resources into design dir
    copy_resources(resources, design_dir)

    # 1) read top module after merge
    try:
        top_module = read_top_module(design_dir)
    except Exception as e:
        print(json.dumps({"success": False, "error_message": str(e)}))
        sys.exit(1)

    # 2) create verilator.f
    try:
        _ = make_verilator_f(design_dir)
    except Exception as e:
        print(json.dumps({"success": False, "error_message": str(e)}))
        sys.exit(1)

    # 3) results dir (date bucket)
    date_tag = datetime.now().strftime("%Y-%m-%d")
    results_dir = design_dir / "results" / date_tag
    results_dir.mkdir(parents=True, exist_ok=True)

    # 4) build sim
    rc, out_build = run_cmd(["make", "-f", "Makefile", "build_verilator_sim"], cwd=design_dir)
    if rc != 0:
        print(json.dumps({"success": False, "error_message": "Build failed", "log": out_build}))
        sys.exit(1)

    # 5) run regression
    rc, out_reg = run_cmd(["make", "-f", "Regression.mk"], cwd=design_dir)
    if rc != 0:
        print(json.dumps({"success": False, "error_message": "Regression failed", "log": out_reg}))
        sys.exit(1)

    # 6) parse summary
    summary_csv = find_latest_summary(results_dir)
    if not summary_csv:
        print(json.dumps({"success": False, "error_message": "regression_summary.csv not found"}))
        sys.exit(1)

    func_score, total_instr, passed_instr = compute_score(summary_csv)
    ipc, ipc_instr, ipc_cycles = compute_ipc(summary_csv)

    # 7) zip results
    results_zip = design_dir / "results.zip"
    zip_path = zip_dir(results_dir, results_zip)

    # Ensure native Python types for JSON serialization
    func_score = float(round(func_score, 4))
    total_instr = int(total_instr)
    passed_instr = int(passed_instr)
    ipc = float(ipc)
    ipc_instr = int(ipc_instr)
    ipc_cycles = int(ipc_cycles)

    print(json.dumps({
        "success": True,
        "functionality_score": func_score,
        "details": {
            "note": "Evaluator ran regression with Regression.mk",
            "design": str(design_dir),
            "top_module": top_module,
            "total_instructions": total_instr,
            "instructions_passed": passed_instr,
            "ipc": ipc,
            "ipc_instructions": ipc_instr,
            "ipc_cycles": ipc_cycles,
            "summary_csv": str(summary_csv),
            "results_zip": zip_path
        }
    }))

if __name__ == "__main__":
    main()
